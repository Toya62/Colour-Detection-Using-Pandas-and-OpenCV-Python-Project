# Colour-Detection-Using-Pandas-and-OpenCV-Python-Project

This project uses OpenCV to detect RGB Colors that are benith the cursor pointer and Identifies it's names using the colors.csv data.

### To run the code use the following terminal command:
python colorDetection.py -i colorpic.jpg


![Color Detection GIF](https://user-images.githubusercontent.com/15246084/83334667-b0ff4d80-a2c5-11ea-9112-c268fd05676f.gif)

(GIF)
